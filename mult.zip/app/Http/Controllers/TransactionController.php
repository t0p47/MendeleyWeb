<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Transaction;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Collection;

class TransactionController extends Controller
{
	protected $header;
	protected $user;
	protected $admin_user = "admin_user";
	protected $simple_user = "web";
	
	public function __construct(){
		
		$this->middleware('nobody.user');
		
		$this->header = "Default header";
		
	}
	
    //
	public function all(){
		
		//Администратор
		if(Auth::guard($this->admin_user)->check()){
			
			$transactions = Transaction::select(['id','user_id','type','amount','details','ip','created_at','updated_at'])->get();
	
			$this->header = "All transactions";
			
			return view('admin-transactions')->with(['transactions'=>$transactions,'header'=>$this->header]);
			
		//Пользователь
		}elseif(Auth::guard($this->simple_user)){
			
			$user_id = Auth::user()->id;
			
			$transactions = Transaction::select(['amount','created_at'])->where('user_id',$user_id)->get();
		
			$this->header = "My transactions";
			
			return view('user-transactions')->with(['transactions'=>$transactions,'header'=>$this->header]);
			
		}
	}
	
	public function addRevenue(Request $request){
		
		$this->validate($request,[
		'amount'=>'required',
		'type'=>'required',
		'user_id'=>'required'
		]);
		
		$data = $request->all();
		
		$data = array_add($data, 'ip', $request->ip());
		
		$transaction = new Transaction;
		
		$transaction->fill($data);
		
		$transaction->save();
		
		return redirect('home');
		
	}
	
	public function edit(Request $request){
		
		$this->validate($request,[
			'id'=>'required',
			'amount'=>'required',
		]);
		
		$transaction = Transaction::where('id',$request->id)->first();
		
		$transaction->forceFill([
			'amount'=>$request->amount,
		])->save();
		
		return redirect('all_transactions');
		
		
		
		
		$expense->forceFill([
			'amount'=>$request->amount,
			'details'=>$request->details,
		])->save();
		
		return redirect('expenses_list');
		
	}
	
	
	
	
}
