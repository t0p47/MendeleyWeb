<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Illuminate\Support\Str;

class UserController extends Controller
{
    //
	public function editUser(Request $request){
		
		$this->validate($request,[
			'user_id'=>'required',
			'name'=>'required|max:255',
			'email'=>'required|max:255|email',
			'password'=>'required|confirmed|min:6',
		]);
		
		$user = User::where('id',$request->user_id)->first();
		
		$user->forceFill([
			'name' => $request->name,
			'email' => $request->email,
            'password' => bcrypt($request->password),
            'remember_token' => Str::random(60),
        ])->save();
		
		return redirect('users_list');
	}
}
