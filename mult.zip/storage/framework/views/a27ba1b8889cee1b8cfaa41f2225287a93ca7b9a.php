<?php $__env->startSection('styles'); ?>


  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">
  
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href=" <?php echo e(asset('/bower_components/adminLTE/plugins/datepicker/datepicker3.css')); ?>">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href=" <?php echo e(asset('/bower_components/adminLTE/plugins/timepicker/bootstrap-timepicker.min.css')); ?>">


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Users</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			
				<table id="users-table" class="table table-striped table-bordered" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>User_id</th>
                <th>Type</th>
				<th>Amount</th>
				<th>Details</th>
				<th>IP</th>
				<th>Created_at</th>
				<th>Updated_at</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>User_id</th>
                <th>Type</th>
				<th>Amount</th>
				<th>Details</th>
				<th>IP</th>
				<th>Created_at</th>
				<th>Updated_at</th>
            </tr>
        </tfoot>
        <tbody>
			<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				
				<tr>
					<td><a class="transaction-edit" data-toggle="modal" data-target="#edittransaction" data-id="<?php echo e($transaction->id); ?>" data-amount="<?php echo e($transaction->amount); ?>"><?php echo e($transaction->id); ?></a></td>
					<td><a class="user-get"><?php echo e($transaction->user_id); ?></a></td>
					<td><a class="transaction-edit" data-toggle="modal" data-target="#edittransaction" data-id="<?php echo e($transaction->id); ?>" data-amount="<?php echo e($transaction->amount); ?>"><?php echo e($transaction->type); ?></a></td>
					<td><a class="transaction-edit" data-toggle="modal" data-target="#edittransaction" data-id="<?php echo e($transaction->id); ?>" data-amount="<?php echo e($transaction->amount); ?>"><?php echo e($transaction->amount); ?></a></td>
					<td><a class="transaction-edit" data-toggle="modal" data-target="#edittransaction" data-id="<?php echo e($transaction->id); ?>" data-amount="<?php echo e($transaction->amount); ?>"><?php echo e($transaction->details); ?></a></td>
					<td><a class="transaction-edit" data-toggle="modal" data-target="#edittransaction" data-id="<?php echo e($transaction->id); ?>" data-amount="<?php echo e($transaction->amount); ?>"><?php echo e($transaction->ip); ?></a></td>
					<td><a class="transaction-edit" data-toggle="modal" data-target="#edittransaction" data-id="<?php echo e($transaction->id); ?>" data-amount="<?php echo e($transaction->amount); ?>"><?php echo e($transaction->created_at); ?></a></td>
					<td><a class="transaction-edit" data-toggle="modal" data-target="#edittransaction" data-id="<?php echo e($transaction->id); ?>" data-amount="<?php echo e($transaction->amount); ?>"><?php echo e($transaction->updated_at); ?></a></td>
				</tr>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
	  
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

<div class="modal fade" id="edittransaction" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit transaction</h4>
      </div>
      <div class="modal-body">
        <?php echo $__env->make('forms.edit-transaction', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>-->
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

	<!-- DataTables -->
	<script src=" <?php echo e(asset('/bower_components/adminLTE/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
	<script src=" <?php echo e(asset('/bower_components/adminLTE/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
	<!-- bootstrap time picker -->
	<script src=" <?php echo e(asset('/bower_components/adminLTE/plugins/timepicker/bootstrap-timepicker.min.js')); ?>"></script>
	<!-- bootstrap datepicker -->
	<script src=" <?php echo e(asset('/bower_components/adminLTE/plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
	
	<script type='text/javascript'>
		$(document).ready(function() {
			$('#users-table').DataTable();
		
			//Date picker
			$('#datepicker').datepicker({
			  autoclose: true
			});
			
			//Timepicker
			$(".timepicker").timepicker({
			  showInputs: false
			});
		
		} );
		
		
	</script>
	
	<script type='text/javascript'>
		$(document).ready(function() {
			var id;
			var amount;
			$('.transaction-edit').click(function(){
				id = $(this).attr('data-id');
				amount = $(this).attr('data-amount');
				$('#id').val(id);
				$('#edittransaction #amount').val(amount);
				var act = "transaction/delete/"+id;
				$('#delete-transaction').attr('action',act);
			});
			
		} );
	</script>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>