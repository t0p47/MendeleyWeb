<form class="form-horizontal" method="POST" action="<?php echo e(route('addExpense')); ?>" autocomplete="off">
                        <?php echo e(csrf_field()); ?>

						
                        <div class="form-group<?php echo e($errors->has('amount') ? ' has-error' : ''); ?>">
                            <label for="amount" class="col-md-4 control-label">Amount</label>

                            <div class="col-md-6">
                                <input id="amount" type="text" class="form-control" name="amount" value="" required autofocus>

                                <?php if($errors->has('amount')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('amount')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group<?php echo e($errors->has('details') ? ' has-error' : ''); ?>">
                            <label for="details" class="col-md-4 control-label">Details</label>

                            <div class="col-md-6">
                                <input id="details" type="text" class="form-control" name="details" value="<?php echo e(old('details')); ?>" required>

                                <?php if($errors->has('details')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('details')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
						
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    Create expense
                                </button>
                            </div>
                        </div>
                    </form>