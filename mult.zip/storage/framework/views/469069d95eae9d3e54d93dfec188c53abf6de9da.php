<?php $__env->startSection('styles'); ?>


  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Users</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			
				<table id="users-table" class="table table-striped table-bordered" width="100%" cellspacing="0">
        <thead>
            <tr>
				<th>Amount</th>
				<th>Created_at</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
				<th>Amount</th>
				<th>Created_at</th>
            </tr>
        </tfoot>
        <tbody>
			<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				
				<tr>
					<td><?php echo e($transaction->amount); ?></td>
					<td><?php echo e($transaction->created_at); ?></td>
				</tr>
				
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
	  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

	<!-- DataTables -->
	<script src=" <?php echo e(asset('/bower_components/adminLTE/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
	<script src=" <?php echo e(asset('/bower_components/adminLTE/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>
	
	<script type='text/javascript'>
		$(document).ready(function() {
			$('#users-table').DataTable();
		} );
	</script>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>