@extends('layouts.admin_template')

@section('styles')


  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">

  
  
  <!-- TODO: IP mask try -->
  <!-- daterange picker -->
  <link rel="stylesheet" href=" {{asset('/bower_components/adminLTE/plugins/daterangepicker/daterangepicker.css')}}">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href=" {{asset('/bower_components/adminLTE/plugins/datepicker/datepicker3.css')}}">
  <!-- iCheck for checkboxes and radio inputs -->
  <link rel="stylesheet" href=" {{asset('/bower_components/adminLTE/plugins/iCheck/all.css')}}">
  <!-- Bootstrap Color Picker -->
  <link rel="stylesheet" href=" {{asset('/bower_components/adminLTE/plugins/colorpicker/bootstrap-colorpicker.min.css')}}">
  <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href=" {{asset('/bower_components/adminLTE/plugins/timepicker/bootstrap-timepicker.min.css')}}">
  <!-- Select2 -->
  <link rel="stylesheet" href=" {{asset('/bower_components/adminLTE/plugins/select2/select2.min.css')}}">

@endsection

@section('content')
<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">Users</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
			
			<button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#createusers">Add user</button>
			
				<table id="users-table" class="table table-striped table-bordered" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
				<th>IP</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
				<th>IP</th>
            </tr>
        </tfoot>
        <tbody>
			@foreach($users as $user)
				
				<tr>
					<td><a class="user-edit" data-toggle="modal" data-target="#edituser" data-id="{{$user->id}}" data-name="{{$user->name}}" data-email="{{$user->email}}" data-ip="{{$user->ip}}">{{$user->id}}</a></td>
					<td><a class="user-edit" data-toggle="modal" data-target="#edituser" data-id="{{$user->id}}" data-name="{{$user->name}}" data-email="{{$user->email}}" data-ip="{{$user->ip}}">{{$user->name}}</a></td>
					<td><a class="user-edit" data-toggle="modal" data-target="#edituser" data-id="{{$user->id}}" data-name="{{$user->name}}" data-email="{{$user->email}}" data-ip="{{$user->ip}}">{{$user->email}}</a></td>
					<td><a class="user-edit" data-toggle="modal" data-target="#edituser" data-id="{{$user->id}}" data-name="{{$user->name}}" data-email="{{$user->email}}" data-ip="{{$user->ip}}">{{$user->ip}}</a></td>
				</tr>
				
			@endforeach
        </tbody>
    </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
	  
@endsection

@section('modal')

<div class="modal fade" id="createusers" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Add User</h4>
      </div>
      <div class="modal-body">
        @include('forms.register')
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>-->
    </div>
  </div>
</div>

<div class="modal fade" id="edituser" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit User</h4>
      </div>
      <div class="modal-body">
        @include('forms.edit-user')
      </div>
      <!--<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>-->
    </div>
  </div>
</div>

@endsection

@section('script')

	<!-- DataTables -->
	<script src=" {{asset('/bower_components/adminLTE/plugins/datatables/jquery.dataTables.min.js')}}"></script>
	<script src=" {{asset('/bower_components/adminLTE/plugins/datatables/dataTables.bootstrap.min.js')}}"></script>
	
	<!-- TODO: IP mask try -->
	<!-- InputMask -->
	<script src=" {{asset('/bower_components/adminLTE/plugins/input-mask/jquery.inputmask.js')}}"></script>
	<script src=" {{asset('/bower_components/adminLTE/plugins/input-mask/jquery.inputmask.date.extensions.js')}}"></script>
	<script src=" {{asset('/bower_components/adminLTE/plugins/input-mask/jquery.inputmask.extensions.js')}}"></script>
	
	<script type='text/javascript'>
		$(document).ready(function() {
			$('#users-table').DataTable();
		} );
	</script>
	<script type='text/javascript'>
		$(document).ready(function() {
			var id;
			var name;
			var email;
			$('.user-edit').click(function(){
				id = $(this).attr('data-id');
				name = $(this).attr('data-name');
				email = $(this).attr('data-email');
				$('#user_id').val(id);
				$('#edituser #name').val(name);
				$('#edituser #email').val(email);
				var act = "user/delete/"+id;
				$('#delete-user').attr('action',act);
			});
			
		} );
	</script>
	<!-- TODO: IP mask try -->
	<script type="text/javascript">
		$(document).ready(function(){
			//Initialize Select2 Elements
			$(".select2").select2();

			//Datemask dd/mm/yyyy
			$("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
			//Datemask2 mm/dd/yyyy
			$("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
			//Money Euro
			$("[data-mask]").inputmask();

			//Date range picker
			$('#reservation').daterangepicker();
			//Date range picker with time picker
			$('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
			//Date range as a button
			$('#daterange-btn').daterangepicker(
				{
				  ranges: {
					'Today': [moment(), moment()],
					'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
					'Last 7 Days': [moment().subtract(6, 'days'), moment()],
					'Last 30 Days': [moment().subtract(29, 'days'), moment()],
					'This Month': [moment().startOf('month'), moment().endOf('month')],
					'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
				  },
				  startDate: moment().subtract(29, 'days'),
				  endDate: moment()
				},
				function (start, end) {
				  $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
				}
			);

			//Date picker
			$('#datepicker').datepicker({
			  autoclose: true
			});

			//iCheck for checkbox and radio inputs
			$('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
			  checkboxClass: 'icheckbox_minimal-blue',
			  radioClass: 'iradio_minimal-blue'
			});
			//Red color scheme for iCheck
			$('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
			  checkboxClass: 'icheckbox_minimal-red',
			  radioClass: 'iradio_minimal-red'
			});
			//Flat red color scheme for iCheck
			$('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
			  checkboxClass: 'icheckbox_flat-green',
			  radioClass: 'iradio_flat-green'
			});

			//Colorpicker
			$(".my-colorpicker1").colorpicker();
			//color picker with addon
			$(".my-colorpicker2").colorpicker();

			//Timepicker
			$(".timepicker").timepicker({
			  showInputs: false
			});
		});
	</script>
	
@endsection