@extends('layouts.admin_template')

@section('content')
<div class="row">
	<div class="col-md-4">
		<div class="box">
			<div class="box-header with-border">
			  <h3 class="box-title">Revenue box (Standart)</h3>

			  <div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i></button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i></button>
			  </div>
			</div>
			<div class="box-body">
				<form autocomplete="off" method="post" action="{{route('addRevenue')}}">
				
				{{csrf_field()}}
				
					<input type="button" class="btn btn-block btn-success dollar-btn" value="1$">
					<input type="button" class="btn btn-block btn-success dollar-btn" value="5$">
					<input type="button" class="btn btn-block btn-success dollar-btn" value="15$">
					<input type="button" class="btn btn-block btn-success dollar-btn" value="30$">
					<input type="button" class="btn btn-block btn-success dollar-btn" value="50$">
					<br>
					<div class="input-group">
						
						<input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
						<input type='hidden' name='type' value="revenue">
						<input class="form-control" id="standart" type="text" name='amount'>
						<div class="input-group-btn">
						  <button type="submit" class="btn btn-success">Post revenue</button>
						</div>
						<!-- /btn-group -->
					</div>
				</form>
			  
			</div>
			<!-- /.box-body -->
		  </div>
	  </div>
	  
	  <div class="col-md-4">
		<div class="box">
			<div class="box-header with-border">
			  <h3 class="box-title">Revenue box (Slider)</h3>

			  <div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i></button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i></button>
			  </div>
			</div>
			<div class="box-body">
				<input type="button" class="btn btn-block btn-success" value="1$">
				<input type="button" class="btn btn-block btn-success" value="5$">
				<input type="button" class="btn btn-block btn-success" value="15$">
				<input type="button" class="btn btn-block btn-success" value="30$">
				<input type="button" class="btn btn-block btn-success" value="50$">
				<br>
				<div class="input-group">
					
					<input class="form-control" type="number">
					<div class="input-group-btn">
					  <button type="button" class="btn btn-success">Post revenue</button>
					</div>
					<!-- /btn-group -->
				  </div>
			  
			</div>
			<!-- /.box-body -->
		  </div>
	  </div>
	  
	  <div class="col-md-4">
		<div class="box">
			<div class="box-header with-border">
			  <h3 class="box-title">Transactions</h3>

			  <div class="box-tools pull-right">
				<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
				  <i class="fa fa-minus"></i></button>
				<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
				  <i class="fa fa-times"></i></button>
			  </div>
			</div>
			<div class="box-body">			  
				<a type="button" class="btn btn-info" href="{{url('all_transactions')}}"> My transactions list </a>
			</div>
			<!-- /.box-body -->
		  </div>
	  </div>
</div><!-- /.row -->

<script type='text/javascript'>
	$(document).ready(function() {
		var sum = 0;
		$('.dollar-btn').click(function(){
			var add = $(this).val();
			sum = parseInt(sum) + parseInt(add);
			$('#standart').val(sum);
		});
	} );
</script>

@endsection
